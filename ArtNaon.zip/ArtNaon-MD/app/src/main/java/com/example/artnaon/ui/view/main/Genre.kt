package com.example.artnaon.ui.view.main

data class Genre(val name: String)


